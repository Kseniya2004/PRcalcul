﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PR20.Pages
{
    /// <summary>
    /// Логика взаимодействия для Eight.xaml
    /// </summary>
    public partial class Eight : Page
    {     
        public Eight()
        {
            InitializeComponent();
        }

        private void btnBuy_Click(object sender, RoutedEventArgs e)
        {
            lstResult.Items.Clear();
            lstResult.Items.Add($"{DateTime.Now}");
            lstResult.Items.Add("Заказ:");
            int a = 0, b = 0, c = 0, d = 0;
            if (CbEdit1.IsChecked == true) 
            {
                a = int.Parse(txtEdit1.Text) * 80;
                lstResult.Items.Add($"Чизбургер {txtEdit1.Text}* 80руб = {a}");
            }
            if (CbEdit1.IsChecked == true)
            {
                b = int.Parse(txtEdit2.Text) * 120;
                lstResult.Items.Add($"Гамбургер {txtEdit2.Text}* 120руб = {b}");
            }               
            if (CbEdit1.IsChecked == true)
            {
                c = int.Parse(txtEdit3.Text) * 62;
                lstResult.Items.Add($"Кока-кола {txtEdit3.Text}* 62руб = {c}");
            }                
            if (CbEdit1.IsChecked == true)
            {
                d = int.Parse(txtEdit4.Text) * 90;
                lstResult.Items.Add($"Нагетсы {txtEdit4.Text}* 90руб = {d}");
            }
            lstResult.Items.Add("---------------");
            lstResult.Items.Add($"К оплате: {a+b+c+d}");
        }       

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            clsFrame.frmObject.Navigate(new Two());
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            lstResult.Items.Clear();
        }
    }
}
