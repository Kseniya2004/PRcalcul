﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace PR20.Pages
{
    /// <summary>
    /// Логика взаимодействия для Two.xaml
    /// </summary>
    public partial class Two : Page
    {
        StreamWriter sw = new StreamWriter(@"Rezult.txt", false, Encoding.Default);
        public Two()
        {
            InitializeComponent();          
            
        }

        private void btnCalcul_Click(object sender, RoutedEventArgs e)
        {
            double sum, dif, com, priv;
            try
            {                
                sum = int.Parse(ChisloOne.Text) + int.Parse(ChisloTwo.Text);
                txtSum.Text = $"Сумма: {sum}";
                dif = int.Parse(ChisloOne.Text) - int.Parse(ChisloTwo.Text);
                txtDif.Text = $"Разность: {dif}";
                com = int.Parse(ChisloOne.Text) * int.Parse(ChisloTwo.Text);
                txtCom.Text = $"Произведение: {com}";
                priv = int.Parse(ChisloOne.Text) / int.Parse(ChisloTwo.Text);
                txtPriv.Text = $"Частное: {priv}";
                sw.WriteLine("Калькулятор");
                sw.WriteLine($"{txtSum.Text}, {txtDif.Text}, {txtCom.Text}, {txtPriv.Text}");
                sw.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Делить на ноль нельзя", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                ChisloTwo.Clear();
                ChisloTwo.Focus();               
            }
           
        }

        private void btnTen_Click(object sender, RoutedEventArgs e)
        { 
            sw.Close();
            clsFrame.frmObject.Navigate(new Eight());
        }
        
    }
}
