﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace PR20
{
    class clsFrame
    {
        public static Frame frmObject;
    }
}
